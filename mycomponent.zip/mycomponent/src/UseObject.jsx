import React from 'react'

function user(props) {
  const {name, Age} = props.details;
  return (
    <div>Object value: {name}</div>
  )
}

export default user;
