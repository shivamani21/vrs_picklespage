import './App.css'; // Import your CSS for styling
import FirstComponent from './FirstComponent'; // Import the component without .jsx
import SecondComponent from './SecondComponent'; // Import the component without .jsx
import UseObject from './UseObject';

let a = 10;
let b = 20;
//object creation and usage
const user = {
  name:"Ramu",
  Age:"19",
  city:"Mumbai"
}
function App() {
  return (
    <div className="App">
      <FirstComponent name = "Shivamani"/>
      <SecondComponent name = "Bandari"/>
      <UseObject details = {user}/>

      {/* <UseObject name = {user.name}/> */}
      A value: {a} <span></span>
      B value: {b}
    </div>
  );
}
export default App;
