import React from 'react'

function FirstComponent(props) {
  return (
    <div>Name: {props.name}</div>
  )
}

export default FirstComponent
