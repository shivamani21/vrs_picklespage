import React from 'react'

function SecondComponent(props) {
  return (
    <div>Name: {props.name}</div>
  )
}


export default SecondComponent
